
import java.io.Serializable;

public abstract class AkcijaParsera implements Serializable {
	
	private static final long serialVersionUID = 26263876880823540L;
	public static final char POMAKNI = 'P',
			REDUCIRAJ = 'R',
			PRIHVATI = 'A',
			ODBACI = 'O';
}
